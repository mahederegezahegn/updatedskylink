<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=M+PLUS+Rounded+1c:wght@100&family=Nanum+Myeongjo:wght@700&family=Playfair+Display+SC&family=Raleway:wght@100&display=swap" rel="stylesheet">
<link rel="stylesheet" href="news.css">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
      <title>Dire International Technology Expo</title>     <link rel="icon" type="image/png" href="assets/images/Ict expo final .png">
                 <link rel="icon" type="image/png" href="assets/images/Ict expo final .png">
 </head>
<body>

  <!-- Header -->
  <header>
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
      <div class="container">
           <a class="navbar-brand" href="index.html">
            <img  class="dark-logo" alt="Skylink Technologies" width="210" height="100px" src="assets/images/Ict expo final .png" /></a>
        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link active " href="index.html">Home</a>
            </li>
            <li class="nav-item ">
              <a class="nav-link "  href="about.html">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="program.html">Program</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="exhibitors.html">Exhibitors</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="attend.html">Attend</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="what_new.php">News</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="sponsors.html">sponsors</a>
            </li>
            
            <li class="nav-item">
              <a class="nav-link" href="contact.html">Contact Us</a>
            </li>
          </ul>
        </div>

      </div>
    </nav>
  </header>
  <?php
include_once('dbcon.php');
// Fetch breaking news from the event table
$query = "SELECT * FROM events WHERE event_type = 'breaking-n' ORDER BY event_date DESC LIMIT 3"; // Adjust the query based on your table structure
$result = mysqli_query($mysqli, $query);
?>

<section>
    <h1 class="text-center">Breaking News</h1>
    <div id="breaking-news-slider">
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <div class="slide">
                <img src="admin/<?php echo $row['event_image']; ?>" alt="Breaking News">
                <div class="slide-content">
                 <div class="side">
                 <h2><?php echo $row['event_title']; ?></h2>
                    <h3><?php echo $row['event_date'];?></h3>
                 </div>
                    <p><?php echo $row['event_description']; ?></p>
                </div>
            </div>
        <?php } ?>
    </div>
</section>

<?php
// Assuming you have a database connection established

// Fetch events and news from the events table
$query = "SELECT * FROM events WHERE event_type IN ('event', 'news') ORDER BY event_date DESC"; // Adjust the query based on your table structure
$result = mysqli_query($mysqli, $query);

?>

<div class="content">
    <h2 class="text-center">Upcoming Events and News</h2>
    <section class="event-news-section">
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <div class="card <?php echo $row['event_type'] == 'event' ? 'event-card' : 'news-card'; ?>">
            <h1><?php echo $row['event_type'];?></h1>
                <img src="admin/<?php echo $row['event_image']; ?>" alt="<?php echo $row['event_title']; ?>">
                <div class="card-content">
                    <h3><?php echo $row['event_title']; ?></h3>
                    <p><?php echo $row['event_description']; ?></p>
                </div>
            </div>
        <?php } ?>
    </section>
</div>


    <script>
      // Slide the breaking news
const slides = document.querySelectorAll('.slide');
let currentSlideIndex = 0;

function showSlide(index) {
    slides.forEach((slide, i) => {
        if (i === index) {
            slide.style.display = 'block';
        } else {
            slide.style.display = 'none';
        }
    });
}

function slideNext() {
    currentSlideIndex++;
    if (currentSlideIndex === slides.length) {
        currentSlideIndex = 0;
    }
    showSlide(currentSlideIndex);
}

// Change the slide every 5 seconds
setInterval(slideNext, 6000);

// Show the first slide initially
showSlide(currentSlideIndex);
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>