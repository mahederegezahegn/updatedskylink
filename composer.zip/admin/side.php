<aside class="sidebar">
      <h1 class="header">Dashboard</h1>
      <ul>
        <li>
          <a href="dash.php">
          <i class="fas fa-calendar-alt"></i>
            Events
          </a>
        </li>
        <li>
          <a href="approve.php">
            <i class="fas fa-chart-bar"></i>
            Approve
          </a>
        </li>
        <li>
          <a href="user.php">
            <i class="fas fa-user"></i>
            Registors
          </a>
        </li>
        <!-- <li>
          <a href="#">
            <i class="fas fa-cog"></i>
            Settings
          </a>
        </li> -->
      </ul>
    </aside>